function change_price(price)
{
  document.getElementById("premprice").innerHTML = price / 100;
};
